const SquaredNumber = (arr) => {
    return arr.map((num) => num * num);
}

const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const squaredNumbers = SquaredNumber(arr);
console.log(squaredNumbers); 