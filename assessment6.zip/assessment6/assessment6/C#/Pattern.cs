﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_
{
    internal class Pattern
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of rows: ");
            int n = Convert.ToInt32(Console.ReadLine());
            for(int i = 1; i <= n; i++)
            {
                for(int j = 1; j <= i; j++)
                {
                    Console.Write(j+ " ");
                }
                Console.WriteLine();
            }
        }
    }
}
