﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_
{
    internal class ArrayOperations
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("enter the array length");
            int n = Convert.ToInt32(Console.ReadLine());
            int[] numbers = new int[n];
            Console.WriteLine("Enter 5 numbers");
            for(int i = 0; i < n; i++)
            {
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }
            
            int sum = 0;
            for(int i = 0; i < n; i++)
            {
                sum += numbers[i];
            }
            Console.WriteLine("The sum of the numbers is:" + sum);
            int max = numbers[0];
            for(int i = 1; i < n; i++)
            {
                if(numbers[i] > max)
                {
                    max = numbers[i];
                }
            }
            Console.WriteLine("The maximum number is:" + max);
            int min = numbers[0];
            for(int i = 1; i < n; i++)
            {
                if(numbers[i] < min)
                {
                    min = numbers[i];
                }
            }
            Console.WriteLine("The minimum number is:" + min);
            int avg = sum / n;
            Console.WriteLine("The average of the numbers is:" + avg);
        }
    }
}
